select
       USER_NAME,
       SCHEMA_NAME,
       sum(case when upper(schema_name) like '%HDP%' then 1 else 0 end) as ACCESS_COUNT,
       max(case when upper(schema_name) like '%HDP%' then TO_CHAR(START_TIME, 'YY-MON-DD HH12:MM:SS') else NULL end) as ACCESS_TIMESTAMP
from
     snowflake.account_usage.query_history
where
      schema_name like '%HDP%'
group by
         user_name,
         schema_name
;