select LOGIN_ID,
       SSO_APPLICATION_NAME,
       APP_ID,
       ACCESS_TIMESTAMP
from (select UPPER(actors_name) as LOGIN_ID,
             record['Requested Application Name']::string  as SSO_APPLICATION_NAME,
             record['Requested Application ID']::string    as APP_ID,
             TO_CHAR(max(record_date), 'DD-MON-YY HH12:MM:SS') as ACCESS_TIMESTAMP
from cybr_db.phdp_cybr_tier3_npi.pingid
group by actors_name, record['Requested Application Name'], record['Requested Application ID'])
where APP_ID is not NULL
;