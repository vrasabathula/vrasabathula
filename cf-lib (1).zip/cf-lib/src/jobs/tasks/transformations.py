import re


class SplunkLegacyTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.table_to_load = kwargs['table_name']

    def transform(self, source_data):
        pattern = r'(\w{3}\d{3}$)'
        if source_data[0]:
            if len(source_data[0]) > 250:
                source_data[0] = re.findall(pattern, source_data[0])[0]
        return source_data

    def get_extra_columns(self, source_data):
        return {}


class SsoNextgenTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def transform(self, source_data):
        return source_data


class SnowflakeUsageOracleColumnsTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def transform(self, source_data):
        return source_data


class PingCentralSfColumnsTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def transform(self, source_data):
        return source_data


class SnowflakePingOracleTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def transform(self, source_data):
        return source_data

    def get_extra_columns(self, source_data):
        return {}


class OnelakeLegacySsoOracleTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def transform(self, source_data):
        return source_data


class PingCentralMappingDataTransformation(object):
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def transform(self, source_data):
        return source_data
