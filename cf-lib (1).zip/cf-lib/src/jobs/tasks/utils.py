import datetime as dt


def get_extra_columns_for_oracle(oracle_instance, pk_rec_keys, source_data):
    try:
        tx_guid = oracle_instance.get_guid()
        return {
            "TRANSACTIONGUID": tx_guid,
            'LASTUPDATEDDTTM': dt.datetime.now().strftime("%y-%b-%d %I:%M:%S"),
            'LASTEDUPDATEDBY': 'star_configurable_loader',
            'PK_REC': '|'.join([source_data.get(key) or "" for key in pk_rec_keys])
        }
    except Exception as e:
        raise e

# class DefaultExtraColumns(object):
#     def __init__(self, **kwargs):
#         self.kwargs = kwargs
#         self.table_to_load = kwargs['table_name']
#         if kwargs.get('target_type') == 'ORACLEDB':
#             self.conn = star_oracle_connection_helper.OracleConnectionHelper()
#             self.conn.connect()
#             self.tx_guid = self.conn.start_load(self.table_to_load)
#         else:
#             self.tx_guid = str(uuid.uuid4())
#         self.pk_rec_keys = kwargs.get("pk_rec_keys", [])
#         print(f"INFO: Successfully Generated TRANSACTIONGUID: {self.tx_guid}")
#
#     def get(self, source_data):
#         try:
#             return {
#                 "TRANSACTIONGUID": self.tx_guid,
#                 'LASTUPDATEDDTTM': dt.datetime.now().strftime("%y-%b-%d %I:%M:%S"),
#                 'LASTEDUPDATEDBY': 'star_configurable_loader',
#                 'PK_REC': '|'.join([source_data.get(key) or "" for key in self.pk_rec_keys])
#             }
#         except Exception as e:
#             raise e
#
#
# class PingcentralSfColumns(DefaultExtraColumns):
#     def get(self, source_data):
#         extra_columns_map = super().get(source_data)
#         extra_columns_map['LASTUPDATEDDTTM'] = dt.datetime.now().strftime("%y-%m-%d %I:%M:%S")
#         return extra_columns_map
#
#
# class SnowflakeUsageOracleColumns(DefaultExtraColumns):
#     pass
#
#
# class SnowflakePingOracleColumns(DefaultExtraColumns):
#     pass
#
#
# class SplunkLegacySsoOracle(DefaultExtraColumns):
#     def get(self, source_data):
#         pattern = r'(\w{3}\d{3}$)'
#         extra_columns_map = super().get(source_data)
#         if source_data["eid"]:
#             if len(source_data["eid"]) > 250:
#                 extra_columns_map["PK_REC"] = re.findall(pattern, source_data['eid'])[0] + source_data['connection_id']
#         return extra_columns_map
#
# class SSONextgen(DefaultExtraColumns):
#     pass
#
#
# class pingcentralmappingdata(DefaultExtraColumns):
#     def get(self, source_data):
#         extra_columns_map = super().get(source_data)
#         extra_columns_map['LASTUPDATEDDTTM'] = dt.datetime.now().strftime("%y-%b-%d %I:%M:%S")
#         return extra_columns_map
#
