import os

GLOBAL_VALUES = {
    'lastedupdatedby': os.getenv('lastedupdatedby'),
    # 'notes' : os.getenv('notes')
}

DTYPE_MAP = {
    'BUCKET_NAME': str,
    'ERROR_CODE': str,
    'EVENT_TYPE': str,
    'EVENT_NAME': str,
    'USER_ID': str,
    'USER_NAME': str,
    'ACCOUNT_ID': str,
    'REGION': str,
    'RECIPIENT_ACCOUNT': str,
    'EID': str,
    'AWS_ROLE': str,
    'ACCOUNTID': str,
    'ARN': str,
    'EVENT_COUNT': int,
    'ACTIVITYCOUNT_SUM': int,
    'COUNT': int
}

DATETIME_MAP = {
    # s3
    'EVENT_DATE': '%Y-%m-%d',
    # all
    'ACCESS_TIMESTAMP': '%Y-%m-%d %H:%M:%S',
    'EVENT_TIME': '%Y-%m-%d %H:%M:%S'
}

PANDAS_TS_FMT = '%Y-%m-%d %H:%M:%S'
ORACLE_TS_FMT = 'YYYY-MM-DD HH24:MI:SS'

# PK_VALUES = os.getenv('pk_values').split(',')
PK_KEY = 'PK_REC'
