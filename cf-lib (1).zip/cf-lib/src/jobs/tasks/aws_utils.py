from io import BytesIO

import boto3

LAST_ACCESS_FILENAME = 'last_access.txt'


def get_last_run(bucket_name, job_name):
    session = boto3.Session()
    s3_client = session.client("s3")

    f = BytesIO()
    s3_client.download_fileobj(bucket_name, f'{job_name}/{LAST_ACCESS_FILENAME}')
    return f.getvalue().decode().strip()


def save_last_run(bucket_name, job_name, timestamp):
    session = boto3.Session()
    s3 = session.resource('s3')

    obj = s3.Object(bucket_name, f'{job_name}/{LAST_ACCESS_FILENAME}')
    result = obj.put(Body=timestamp.encode())

    res = result.get('ResponseMetadata')
    print(res)
