import os
import s3fs
import pytz
import json
import boto3
import requests
import warnings
from datetime import date, datetime, timezone, timedelta

from dateutil.parser import parse
from botocore.session import get_session
from botocore.credentials import RefreshableCredentials

warnings.filterwarnings("ignore")

class OAUTH_SERVICES:

    def __init__(self, **kwargs):
        self.ClientID = os.getenv(kwargs['ClientID'])
        self.ClientSecret = os.getenv(kwargs['ClientSecret'])
        self.DatasetID = kwargs['DatasetID']
        self.Bucket = kwargs['Bucket']
        self.Prefix = kwargs['Prefix']
        self.env = kwargs['env']
        self.host = self._get_hosts()
        self.token = ""
        self.session_tokens = ""
        self.session_keys = {}

    def _get_hosts(self):
        if self.env == 'qa':
            return "api-it.cloud.capitalone.com"
        if self.env == 'prod':
            return "api.cloud.capitalone.com"

    def _get_oauth_token(self):
        """
                Gets an oauth token from /oauth2/token to authenticate calls with.
                Caches the response so that oauth tokens can be reused until they expire.
                :return: The access_token as a string.
        """
        try:
            self.token = requests.post(
                f'https://{self.host}/oauth2/token',
                data={
                    'grant_type': 'client_credentials',
                    'client_id': self.ClientID,
                    'client_secret': self.ClientSecret,
                }, verify=False)
            print(f"INFO: response.status_code : {self.token.status_code} >> {self.token.content}")
            self.token = self.token.json()
            print(f"INFO: Completed fetching Bearer token Talos {self.token}")
            return self.token
        except Exception as e:
            print(f"('Oath token was not retrieved successfully ')")
            raise e

    def _get_session_key(self):
        self.token = self._get_oauth_token()
        url = f"https://{self.host}/internal-operations/data-management/persistence/application-token?datasetId={self.DatasetID}"
        payload = {}
        headers = {
            'accept': 'application/json;v=2',
            'Authorization': f'Bearer {self.token["access_token"]}'
        }

        response = requests.request("GET", url, headers=headers, data=payload, verify=True)
        if response.status_code != 200:
            raise Exception(f"400 Client Error: Bad Request for {url}")
        self.session_tokens = response.text.encode('utf8')
        decode_keys = self.session_tokens.decode('utf8').replace("'", '"')
        data = json.loads(decode_keys)
        self.session_keys = {
            "AccessKeyId": data['credentials']['accessKeyId'],
            "SecretAccessKey": data['credentials']['secretAccessKey'],
            "SessionToken": data['credentials']['sessionToken'],
            "expirationTimestamp": data['credentials']['expirationTimestamp'],
            "networkTransactionId": data['networkTransactionId'],
            "userResourceName": data['userResourceName']
        }
        expiry_time = (
                datetime.now(timezone.utc) + timedelta(hours=1)
        ).isoformat()
        print(f"expiry_time: {expiry_time}")
        print(f"export AWS_ACCESS_KEY_ID={data['credentials']['accessKeyId']}")
        print(f"export AWS_SECRET_ACCESS_KEY={data['credentials']['secretAccessKey']}")
        print(f"export AWS_SESSION_TOKEN={data['credentials']['sessionToken']}")

        return self.session_keys

    def _is_token_expired(self) -> bool:
        """
        Checks this object's current token to see if it is expired.
        :return: True if _token is invalid or past expiry time; otherwise, False.
        """
        self.token = self._get_oauth_token()
        if not isinstance(self.token, dict):
            return True

        if (
                "issued_at" not in self.token
                or "expires_in" not in self.token
                or "access_token" not in self.token
        ):
            return True
        expiry_time = datetime.fromtimestamp(
            self.token["issued_at"] + self.token["expires_in"]
        )
        if datetime.now() > expiry_time:
            return True
        return False

    def _get_s3_session(self, credentials=None):

        if not credentials:
            credentials = self._get_session_key()
        boto_session = boto3.Session(
            aws_access_key_id=credentials["AccessKeyId"],
            aws_secret_access_key=credentials["SecretAccessKey"],
            aws_session_token=credentials["SessionToken"],
            region_name='us-east-1'
        )

        return boto_session

    def _boto_s3_client(self):
        return self._get_s3_session().client('s3')

    def _s3_filesystem(self):
        credentials = self._get_session_key()
        os.environ["AWS_ACCESS_KEY_ID"] = credentials["AccessKeyId"]
        os.environ["AWS_SECRET_ACCESS_KEY"] = credentials["SecretAccessKey"]
        os.environ["AWS_SESSION_TOKEN"] = credentials["SessionToken"]
        s3 = s3fs.S3FileSystem(key=credentials["AccessKeyId"], secret=credentials["SecretAccessKey"],
                               token=credentials["SessionToken"])
        fs = s3fs.core.S3FileSystem(key=credentials["AccessKeyId"], secret=credentials["SecretAccessKey"],
                                    token=credentials["SessionToken"])
        return s3, fs

    def get_s3_url(self, date_string):
        return f"s3://{self.Bucket}/{self.Prefix}{date_string}/compact_version=0/*.gz.parquet"
