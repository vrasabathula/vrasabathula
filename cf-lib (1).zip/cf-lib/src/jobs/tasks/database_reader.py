import os
import re
import yaml
import pytz
import json
import time
import redis
import warnings
import pandas as pd
import mysql.connector
import fastparquet as fp
import snowflake.connector
import splunklib.client as client
import splunklib.results as results
from .Services import OAUTH_SERVICES
import star_oracle_connection_helper
from datetime import date, datetime, timedelta

warnings.filterwarnings("ignore")


class MYSQLDB:
    def __init__(self, **kwargs):
        self.host = kwargs['host']
        self.port = kwargs['port']
        self.username = kwargs['username']
        self.password = os.getenv(kwargs['password'])
        self.db = kwargs['db']
        self.connection = self.connect()

    # def select(self, query, parameters):
    #     return self.execute(query, parameters)

    def connect(self):
        connection = mysql.connector.connect(
            host=self.host,
            port=self.port,
            user=self.username,
            password=self.password,
            database=self.db
        )
        print(f"INFO:  Successfully Connected to MYSQLDB For Instance: {self.host}")
        return connection

    def execute(self, query, selected_columns=None, last_run_timestamp=None):
        data = []
        cursor = self.connection.cursor()
        cursor.execute(query, last_run_timestamp)
        rows = cursor.fetchall()
        for row in rows:
            data.append(row)
        cursor.close()
        return data

    # def dispose(self):
    #     if self.connection:
    #         self.connection.close()


class SNOWFLAKEDB:
    def __init__(self, **kwargs):
        self.host = kwargs['host']
        self.port = kwargs['port']
        self.username = os.getenv(kwargs['username'])
        self.password = os.getenv(kwargs['password'])
        self.db = kwargs['db']
        self.warehouse = kwargs['warehouse']
        self.schema = kwargs['schema']
        self.role = kwargs['role']
        self.connection = self.connect()
        self.cursor = self.get_cursor()

    def connect(self):
        # TODO Need to work on setting Proxy Properly Currently it is not being used
        # self.set_proxy()
        try:
            conn = snowflake.connector.connect(
                    user=self.username,
                    password=self.password,
                    account=self.host,
                    warehouse=self.warehouse,
                    database=self.db,
                    role=self.role,
                    schema=self.schema
                )
            print(f"INFO:  Connected to Snowflake Successfully...")
            return conn
        except Exception as err:
            print(f"{str(err)}")

    def get_cursor(self):
        return self.connect().cursor()

    def execute(self, query, selected_columns=None, last_run_timestamp=None):
        cursor = self.get_cursor()
        cursor.execute(query, (last_run_timestamp,))
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def write(self, table_name, record, columns):
        try:
            cursor = self.get_cursor()
            records_string = ', '.join([str(tuple(x)) for x in record])
            columns_string = ','.join(columns)
            sql = f"INSERT INTO {self.schema}.{table_name} ({columns_string}) VALUES {records_string}"
            if sql:
                cursor.execute(sql)
                cursor.close()
        except snowflake.connector.errors.ProgrammingError as err:
            raise err


class ORACLEDB:
    def __init__(self, **kwargs):
        self.table_name = kwargs['table_name']
        self.connection = None
        print(f"INFO:  Oracle Connection was Successful")

    def get_connection(self):
        if not self.connection:
            self.connection = star_oracle_connection_helper.OracleConnectionHelper()
            self.connection.connect()
        return self.connection

    def get_guid(self):
        return self.get_connection().start_load(self.table_name)

    def get_cursor(self):
        return self.get_connection().get_cursor()

    def write(self, table_name, record, columns):
        data = [dict(zip(columns, value)) for value in record]
        if data:
            self.get_connection().insert_block(data, table_name)
            self.get_connection().commit()


class RedisStore:
    def __init__(self, hostname=os.getenv('redis_host')):
        self.redis_client = redis.StrictRedis(host=hostname, port=6379, db=0,
                                              password=os.getenv('star_redis_token'),
                                              charset="utf-8", decode_responses=True)

    def add_to_list(self, key, values):
        encoded_data = []
        for value in values:
            encoded_data.append(json.dumps(value))
        self.redis_client.lpush(key, *encoded_data)

    def add_to_list_in_batches(self, key, values, chunk_size=10000):
        index = 0
        while index <= len(values):
            self.add_to_list(key, values[index:index + chunk_size])
            index += chunk_size

    def read_list(self, key, start, end):
        stored_items = self.redis_client.lrange(key, start+1, end)
        decoded_data = []
        for item in stored_items:
            decoded_data.append(json.loads(item))
        return decoded_data


class SPLUNK:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.conn = self.connect()

    def connect(self):
        return client.connect(host=self.kwargs['host'], port=self.kwargs['port'],
                              username=self.kwargs['username'], password=self.kwargs['password'],
                              SCHEME=self.kwargs['schema'], autologin=True, basic=True)

    def execute(self, query, selected_columns=None, last_run_timestamp=None):
        try:

            print("INFO:  Connected to splunk")
            kwargs_export = {"earliest_time": "-2Hr",
                             "latest_time": "now",
                             "search_mode": "normal"}

            try:
                oneshot_results = self.conn.jobs.oneshot(query, **kwargs_export)
            except:
                self.conn = self.connect()
                oneshot_results = self.conn.jobs.oneshot(query, **kwargs_export)
            print('INFO:  connection established')
            reader = results.ResultsReader(oneshot_results)
            data = []
            for item in reader:
                values_list = []
                for column in selected_columns:
                    values_list.append(item.get(column, ''))
                data.append(values_list)
            return data

        except Exception as error:
            print(error)
            raise ValueError


class ONELAKE:

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.date_range = kwargs['date_range']
        self.OL = OAUTH_SERVICES(**kwargs)

    @staticmethod
    def _utc_now():
        """
        utcnow does not return timezone info.
        We add it back in with pytz
        """
        t_time = datetime.utcnow()
        return t_time.replace(tzinfo=pytz.UTC)

    def connect(self):
        s3, fs = self.OL._s3_filesystem()
        return s3, fs

    def get_requested_dates(self):
        if self.date_range:
            dd = date.fromisoformat(self._utc_now().strftime("%Y-%m-%d"))
            date_range = [(dd - timedelta(days=day)).isoformat() for day in range(self.date_range)]
            return date_range
        else:
            return datetime.now().strftime("%Y-%m-%d")

    def get_all_file_paths_data(self):
        s3, fs = self.connect()
        dff = []
        for dt_range in self.get_requested_dates():
            all_paths_from_s3 = fs.glob(path=self.OL.get_s3_url(dt_range))
            if not all_paths_from_s3:
                print(f"INFO: no files found for date: {dt_range} in {self.kwargs['Bucket']}")
                return
            s3open = s3.open
            fp_obj = fp.ParquetFile(all_paths_from_s3, open_with=s3open)
            data = fp_obj.to_pandas()
            dff.append(data)
        df = pd.concat(dff)
        print(f"INFO: Get length of concat DataFrame: {len(df)}")
        return df

    def execute(self, query, selected_columns=None, last_run_timestamp=None):
        # Add User Functions to work on the data from Onelake

        def onelake_sso_legacy_qa_dataset():
            df = self.get_all_file_paths_data()
            dff = df['message']
            dff = dff.str.replace('=>', ':')
            dff = dff.str.replace('\\', '')
            dff = dff.str.replace('message', 'message_details')
            dff = dff.loc[dff.str.contains("message", case=False)]
            data_list = []
            for r in dff:
                if 'success|' in r:
                    pattern = r'("message_details":")(20[0-9][0-9]-[0-9]+-[0-9]+\s+\d+:\d+:\d+,\d+)([\w|]+)+(\w|\W\D+\d|)'
                    grouping = re.search(pattern, r).group(4)
                    repl = grouping.replace('"', '').replace("(", "").replace(")", "").replace("#", "")
                    joined_repl = re.search(pattern, r).group(1) + re.search(pattern, r).group(2) + re.search(pattern, r).group(3) + repl
                    r = re.sub(pattern, joined_repl, r)
                    data = yaml.safe_load(r)
                    _dict = {}
                    if data['message_details']:
                            message_details = data['message_details'].split('|')
                            EID = message_details[2].upper().replace(' ', '')
                            EID = EID if len(EID) >= 1 else 'nan'
                            ACCESS_TIMESTAMP = message_details[0].replace(',', '.')
                            ACCESS_TIMESTAMP = str(
                                datetime.strptime(ACCESS_TIMESTAMP, '%Y-%m-%d %H:%M:%S.%f').strftime(
                                    '%Y-%d-%m %I:%M:%S.%f %p'))
                            STATUS = message_details[9].upper().replace(' ', '')
                            APPLICATION_ID = message_details[5].replace(' ', '')
                            APPLICATION_ID = APPLICATION_ID if len(APPLICATION_ID) >= 1 else 'nan'
                            HOST = message_details[3].replace(' ', '')
                            VERSION = message_details[10].replace(' ', '').replace(',', '+').replace('[', '').replace(']',
                                                                                                                      '')
                            VERSION = VERSION if len(VERSION) >= 1 else 'nan'
                            if STATUS == 'SUCCESS' and EID != 'nan' and APPLICATION_ID != 'nan':
                                _dict = {
                                    "EID": EID,
                                    "APPLICATION_ID": APPLICATION_ID,
                                    "HOST": HOST,
                                    "ACCESS_TIMESTAMP": ACCESS_TIMESTAMP,
                                    "STATUS": STATUS,
                                    "VERSION": VERSION,
                                }
                                x = list(_dict.values())
                                data_list.append(x)
            columns = ['EID', 'APPLICATION_ID', 'HOST', 'ACCESS_TIMESTAMP', 'STATUS', 'VERSION']
            df = pd.DataFrame(data_list, columns=columns)
            print(f'INFO: Added Header to DataFrame : {len(df)}')

            grouped_df = df.groupby(['EID', 'APPLICATION_ID']).size().reset_index(name='ACCESS_COUNT')
            dff = pd.merge(df, grouped_df, how='inner', on=['EID', 'APPLICATION_ID'])
            dff.drop_duplicates(subset=['EID', 'APPLICATION_ID', 'ACCESS_COUNT'], keep="first", inplace=True)
            list_tuples = list(dff.itertuples(index=False, name=None))  # Convert DataFrame to List of Tuples
            return list_tuples
        try:
            list_tuples = eval(str(query))()
            return list_tuples
        except Exception as e:
            raise e


class DatabaseReaderFactory(object):
    @classmethod
    def get(cls, db_type, kwargs: dict):
        if db_type == 'MYSQLDB':
            return MYSQLDB(**kwargs)
        elif db_type == 'ORACLEDB':
            return ORACLEDB(**kwargs)
        elif db_type == 'SNOWFLAKEDB':
            return SNOWFLAKEDB(**kwargs)
        elif db_type == 'SPLUNK':
            return SPLUNK(**kwargs)
        elif db_type == 'ONELAKE':
            return ONELAKE(**kwargs)
        else:
            raise Exception("type not defined")
