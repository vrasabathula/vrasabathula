#!/usr/bin/env python3
import os
import sys
import yaml
import luigi
import logging
import warnings
from src.jobs.engine import EXECUTOR

# from jobs.tasks.utils import ChamberSecrets

properties_file = "../config/properties.yaml"
warnings.simplefilter("ignore")
logger = logging.getLogger('run')


def Merge(dict1, dict2):
    return {**dict1, **dict2}


def decision_factor(**kwargs):
    if not luigi.build([
        EXECUTOR(**kwargs)
    ],
            workers=int(os.getenv('luigi_workers', '3')),
            local_scheduler=True
    ):
        sys.exit(1)


class CfLoader(object):
    def __init__(self, properties_file_path, job_name=None):
        self.properties_file_path = properties_file_path
        self.job_name = job_name if job_name else os.getenv('job_name')
        if not self.job_name:
            raise Exception("job_name not defined")

    def get_job_params(self):
        with open(self.properties_file_path) as f:
            conf = yaml.safe_load(f.read())['jobs']
            job_params = None
            for params in conf:
                if os.getenv('job_name') == params['job_name']:
                    logger.info(f"The Given Job Name: {os.getenv('job_name')} is Matched")
                    job_params = params
                    break

        if not job_params:
            raise Exception("config for given job_name not found")

        kwargs = Merge(job_params['db_properties'], job_params['db_upload_info'])
        kwargs = Merge(kwargs, job_params['query_output_columns'])
        kwargs['extra_columns_class'] = job_params['extra_columns_class']
        kwargs['transformations'] = job_params['transformations']
        kwargs['pk_rec_keys'] = job_params['pk_rec_keys']
        kwargs['storage'] = job_params['storage']
        kwargs['job_name'] = job_params['job_name']

        return kwargs

    def start(self):
        params = self.get_job_params()
        decision_factor(**params)


# should be removed once migrated to package
if __name__ == '__main__':
    loader = CfLoader(properties_file)
    loader.start()
